package github.mcdatapack.blocktopia.util;

import github.mcdatapack.blocktopia.villager.CustomVillager;
import java.util.Optional;
import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1914;
import net.minecraft.class_9306;

import static github.mcdatapack.blocktopia.init.blocks.LegacyBlocks.*;

public class CustomTrades {
    public static void load(int maxUses) {
        TradeOfferHelper.registerVillagerOffers(CustomVillager.LEGACY, 1,
                factories -> {
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(COBBLESTONE_RD20090515, 20),
                            maxUses, 1, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(COBBLESTONE_C_0_0_14A, 20),
                            maxUses, 1, 0.75F
                    ));
                    factories.add((entity, random) ->  new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(COBBLESTONE_B1_7, 20),
                            maxUses, 1, 0.75F
                    ));
                    factories.add((entity, random) ->  new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(WHITE_CLOTH, 15),
                            maxUses, 1, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(LIGHT_GRAY_CLOTH_C0_0_20A, 15),
                            maxUses, 1, 0.75F
                    ));
                    factories.add((entity, random) ->  new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(LIGHT_GRAY_CLOTH_C0_28A, 15),
                            maxUses, 1, 0.75F
                    ));
                    factories.add((entity, random) ->  new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(DARK_GRAY_CLOTH_C0_0_20A, 15),
                            maxUses, 1, 0.75F
                    ));
                    factories.add((entity, random) ->  new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(DARK_GRAY_CLOTH_C0_28A, 15),
                            maxUses, 1, 0.75F
                    ));
                    factories.add((entity, random) ->  new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(RED_CLOTH, 15),
                            maxUses, 1, 0.75F
                    ));
                    factories.add((entity, random) ->  new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(ORANGE_CLOTH, 15),
                            maxUses, 1, 0.75F
                    ));
                    factories.add((entity, random) ->  new class_1914 (
                        new class_9306(class_1802.field_8687, 1),
                            new class_1799(YELLOW_CLOTH, 15),
                            maxUses, 1, 0.75F
                    ));
                    factories.add((entity, random) ->  new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(CHARTREUSE_CLOTH, 15),
                            maxUses, 1, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(SPRING_GREEN_CLOTH, 15),
                            maxUses, 1, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(CYAN_CLOTH, 15),
                            maxUses, 1, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(CAPRI_CLOTH, 15),
                            maxUses, 1, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(ULTRAMARINE_CLOTH, 15),
                            maxUses, 1, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(VIOLET_CLOTH, 15),
                            maxUses, 1, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(PURPLE_CLOTH, 15),
                            maxUses, 1, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(MAGENTA_CLOTH, 15),
                            maxUses, 1, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(ROSE_CLOTH, 15),
                            maxUses, 1, 0.75F
                    ));
            });
        TradeOfferHelper.registerVillagerOffers(CustomVillager.LEGACY, 2,
                (factories) -> {
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(TNT_C0_26ST, 8),
                            maxUses, 5, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(TNT_C0_28A, 8),
                            maxUses, 5, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(MOSSY_COBBLESTONE_C0_26ST, 8),
                            maxUses, 5, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(MOSSY_COBBLESTONE_B1_8, 8),
                            maxUses, 5, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(BRICKS_C0_26ST, 8),
                            maxUses, 5, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(BRICKS_A1_0_11, 8),
                            maxUses, 5, 0.75F
                    ));
            });
        TradeOfferHelper.registerVillagerOffers(CustomVillager.LEGACY, 3,
                (factories) -> {
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(WOODEN_PLANKS_RD20090515, 8),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(WOODEN_PLANKS_RD161348, 8),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(WOODEN_PLANKS_C0_0_14A, 8),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(WOODEN_PLANKS_C0_0_15A, 8),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(WOODEN_PLANKS_B1_9PRE5, 8),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(LOG_C0_0_14A, 4),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(SNOW_BLOCK_A1_0_5, 4),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(CLAY_BLOCK_A1_0_11, 4),
                            maxUses, 10, 0.75F
                    ));
            });
        TradeOfferHelper.registerVillagerOffers(CustomVillager.LEGACY, 4,
                (factories) -> {
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 4),
                            new class_1799(GOLD_BLOCK_C0_0_20A, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 4),
                            new class_1799(GOLD_BLOCK_C0_26ST, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 4),
                            new class_1799(GOLD_BLOCK_A1_2_0, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 4),
                            new class_1799(GOLD_BLOCK_B1_9PRE5, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 4),
                            new class_1799(IRON_BLOCK_C0_26ST, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 4),
                            new class_1799(IRON_BLOCK_A1_2_0, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 4),
                            new class_1799(IRON_BLOCK_B1_9PRE5, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, maxUses),
                            new class_1799(DIAMOND_BLOCK_IN20100128, 1),
                            maxUses, 10, 0.12F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, maxUses),
                            new class_1799(DIAMOND_BLOCK_A1_2_0, 1),
                            maxUses, 10, 0.12F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, maxUses),
                            new class_1799(DIAMOND_BLOCK_B1_9PRE5, 1),
                            maxUses, 10, 0.12F
                    ));
            });
        TradeOfferHelper.registerVillagerOffers(CustomVillager.LEGACY, 5,
                (factories) -> {
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 6),
                            new class_1799(OBSIDIAN_C0_28A, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914 (
                            new class_9306(class_1802.field_8687, 64),
                            Optional.of(new class_9306(OBSIDIAN_C0_28A, 20)),
                            new class_1799(BEDROCK_C0_0_12A, 1),
                            maxUses, 30, 0.75F
                    ));
            });


        TradeOfferHelper.registerVillagerOffers(CustomVillager.BEEKEEPER, 1,
                (factories) -> {
                    factories.add((entity, random) -> new class_1914 (
                        new class_9306(class_1802.field_8687, 1),
                        new class_1799(class_1802.field_20414, 2),
                        maxUses, 1, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_8687, 1),
                            Optional.of(new class_9306(class_1802.field_20417, 1)),
                            new class_1799(class_1802.field_8777, 1),
                            maxUses, 1, 0.75F
                    ));
                });
        TradeOfferHelper.registerVillagerOffers(CustomVillager.BEEKEEPER, 2,
                (factories) -> {
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_42696, 24),
                            new class_1799(class_1802.field_20417, 1),
                            maxUses, 5, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_42696, 64),
                            Optional.of(new class_9306(class_1802.field_42688, 2)),
                            new class_1799(class_1802.field_21086, 1),
                            maxUses, 5, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_8777, 1),
                            Optional.of(new class_9306(class_1802.field_8469, 1)),
                            new class_1799(class_1802.field_20417, 1),
                            maxUses, 5, 0.75F
                    ));
                });
        TradeOfferHelper.registerVillagerOffers(CustomVillager.BEEKEEPER, 3,
                factories -> {
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_8491, 2),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_8880, 2),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_17499, 2),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_17500, 2),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_17501, 2),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_17502, 2),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_17509, 2),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_17510, 2),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_17511, 2),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_17512, 2),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_17513, 2),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_17514, 2),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_42695, 2),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_28649, 2),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_28651, 2),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_37508, 2),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_42694, 1),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_42696, 2),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 10, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_28652, 2),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 10, 0.75F
                    ));
        });
        TradeOfferHelper.registerVillagerOffers(CustomVillager.BEEKEEPER, 4,
                (factories) -> {
                    factories.add((entity, random) -> new class_1914(
                                    new class_9306(class_1802.field_17525, 1),
                                    new class_1799(class_1802.field_20413, 1),
                                    maxUses, 20, 0.75F
                            ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_17526, 1),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 20, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_17529, 1),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 20, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_17527, 1),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 20, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_43192, 1),
                            new class_1799(class_1802.field_20413, 1),
                            maxUses, 20, 0.75F
                    ));
        });
        TradeOfferHelper.registerVillagerOffers(CustomVillager.BEEKEEPER, 5,
                (factories) -> {
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(class_1802.field_20414, 4),
                            maxUses, 30, 0.75F
                    ));
                    factories.add((entity, random) -> new class_1914(
                            new class_9306(class_1802.field_8687, 1),
                            new class_1799(class_1802.field_20417, 4),
                            maxUses, 30, 0.75F
                    ));
        });
    }
}
