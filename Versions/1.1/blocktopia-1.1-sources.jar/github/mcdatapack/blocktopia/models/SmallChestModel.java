package github.mcdatapack.blocktopia.models;

import github.mcdatapack.blocktopia.Blocktopia;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3879;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.client.model.*;

public class SmallChestModel extends class_3879 {
	public static final class_5601 LAYER = new class_5601(Blocktopia.id("small_chest"), "main");
	public static final class_2960 TEXTURE_LOCATION = Blocktopia.id("textures/entity/small_chest.png");

	public final class_630 main;
	public final class_630 lid;

	public SmallChestModel(class_630 root) {
        super(class_1921::method_23572);
        this.main = root.method_32086("main");
		this.lid = this.main.method_32086("lid");
	}
	public static class_5607 getTexturedModelData() {
		class_5609 modelData = new class_5609();
		class_5610 modelPartData = modelData.method_32111();
		class_5610 main = modelPartData.method_32117("main", class_5606.method_32108()
				.method_32101(37, 0)
				.method_32098(-6.0F, -3.5F, -6.0F, 12.0F, 8.0F, 1.0F,
						new class_5605(0.0F))
				.method_32101(36, 30)
				.method_32098(-6.0F, -3.5F, 5.0F, 12.0F, 8.0F, 1.0F,
						new class_5605(0.0F))
				.method_32101(23, 30)
				.method_32098(5.0F, -3.5F, -5.0F, 1.0F, 8.0F, 10.0F,
						new class_5605(0.0F))
				.method_32101(0, 30)
				.method_32098(-6.0F, -3.5F, -5.0F, 1.0F, 8.0F, 10.0F,
						new class_5605(0.0F))
				.method_32101(0, 16)
				.method_32098(-6.0F, -4.5F, -6.0F, 12.0F, 1.0F, 12.0F,
						new class_5605(0.0F)),
				class_5603.method_32090(0.0F, 4.5F, 0.0F));

		class_5610 lid = main.method_32117("lid", class_5606.method_32108()
				.method_32101(0, 0)
				.method_32098(-6.0F, 0.0F, -12.0F, 12.0F, 3.0F, 12.0F,
						new class_5605(0.0F))
				.method_32101(0, 0)
				.method_32098(-1.0F, -1.0F, -13.0F, 2.0F, 3.0F, 1.0F, new class_5605(0.0F)),
				class_5603.method_32091(0.0F, 4.5F, 6.0F, 0.0F, 0.0F, 0.0F));
		return class_5607.method_32110(modelData, 64, 64);
	}
	@Override
	public void method_2828(class_4587 matrices, class_4588 vertexConsumer, int light, int overlay, int color) {
		this.main.method_22699(matrices, vertexConsumer, light, overlay, color);
	}

	public class_630 getLid() {
		return this.lid;
	}
}