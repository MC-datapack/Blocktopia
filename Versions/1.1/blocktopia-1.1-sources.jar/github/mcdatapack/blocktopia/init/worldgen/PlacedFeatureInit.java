package github.mcdatapack.blocktopia.init.worldgen;

import github.mcdatapack.blocktopia.Blocktopia;
import github.mcdatapack.blocktopia.init.blocks.BlockInit;
import github.mcdatapack.blocktopia.init.blocks.LegacyBlocks;
import net.minecraft.class_2975;
import net.minecraft.class_5321;
import net.minecraft.class_5450;
import net.minecraft.class_5843;
import net.minecraft.class_6646;
import net.minecraft.class_6658;
import net.minecraft.class_6792;
import net.minecraft.class_6793;
import net.minecraft.class_6795;
import net.minecraft.class_6796;
import net.minecraft.class_6797;
import net.minecraft.class_6799;
import net.minecraft.class_6817;
import net.minecraft.class_6819;
import net.minecraft.class_6880;
import net.minecraft.class_7871;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.world.gen.placementmodifier.*;

import java.util.List;
import java.util.Map;

public class PlacedFeatureInit {
    public static final class_5321<class_6796> PALM_TREE_KEY = registerKey("palm_tree");

    //Legacy

    public static final class_5321<class_6796> COAL_ORE_C0_0_14A_KEY = registerKey("coal_ore_c0_0_14a");
    public static final class_5321<class_6796> COAL_ORE_1_14_KEY = registerKey("coal_ore_1_14");
    public static final class_5321<class_6796> IRON_ORE_C0_0_14A_KEY = registerKey("iron_ore_c0_0_14a");
    public static final class_5321<class_6796> IRON_ORE_1_14_KEY = registerKey("iron_ore_1_14");
    public static final class_5321<class_6796> IRON_ORE_1_14_1_KEY = registerKey("iron_ore_1_14_4");
    public static final class_5321<class_6796> GOLD_ORE_C0_0_14A_KEY = registerKey("gold_ore_c0_0_14a");
    public static final class_5321<class_6796> GOLD_ORE_C0_26ST_KEY = registerKey("gold_ore_c0_26st");
    public static final class_5321<class_6796> GOLD_ORE_1_14_KEY = registerKey("gold_ore_1_14");
    public static final class_5321<class_6796> TREE_C0_24ST_KEY = registerKey("tree_c0_24st");
    public static final class_5321<class_6796> DANDELION_C0_0_20A_KEY = registerKey("dandelion_c0_0_20a");
    public static final class_5321<class_6796> DANDELION_C0_0_20A_PATCH_KEY = registerKey("dandelion_c0_0_20a_patch");
    public static final class_5321<class_6796> ROSE_C0_0_20A_KEY = registerKey("rose_c0_0_20a");
    public static final class_5321<class_6796> ROSE_C0_0_20A_PATCH_KEY = registerKey("rose_c0_0_20a_patch");
    public static final class_5321<class_6796> POPPY_1_7_KEY = registerKey("poppy_1_7");
    public static final class_5321<class_6796> POPPY_1_7_PATCH_KEY = registerKey("poppy_1_7_patch");
    public static final class_5321<class_6796> BROWN_MUSHROOM_C0_0_20A_KEY = registerKey("brown_mushroom_c0_0_20a");
    public static final class_5321<class_6796> BROWN_MUSHROOM_C0_0_20A_PATCH_KEY = registerKey("brown_mushroom_c0_0_20a_patch");
    public static final class_5321<class_6796> RED_MUSHROOM_C0_0_20A_KEY = registerKey("red_mushroom_c0_0_20a");
    public static final class_5321<class_6796> RED_MUSHROOM_C0_0_20A_PATCH_KEY = registerKey("red_mushroom_c0_0_20a_patch");

    public static void bootstrap(class_7891<class_6796> context) {
        class_7871<class_2975<?, ?>> registryLookup = context.method_46799(class_7924.field_41239);
        register(context, PALM_TREE_KEY, registryLookup.method_46747(ConfiguredFeatureInit.PALM_TREE_KEY),
                class_6819.method_39741(
                        class_6817.method_39736(0, 0.1F, 1), BlockInit.PALM_SAPLING));
        register(context, TREE_C0_24ST_KEY, registryLookup.method_46747(ConfiguredFeatureInit.TREE_C0_24ST_KEY),
                class_6819.method_39741(
                        class_6817.method_39736(0, 0.1F, 1), LegacyBlocks.SAPLING_C0_24ST));

        register(context, COAL_ORE_C0_0_14A_KEY, registryLookup.method_46747(ConfiguredFeatureInit.COAL_ORE_C0_0_14A_KEY),
                Modifiers.modifiersCount(30, class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(192))));
        register(context, COAL_ORE_1_14_KEY, registryLookup.method_46747(ConfiguredFeatureInit.COAL_ORE_1_14_KEY),
                Modifiers.modifiersCount(30, class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(192))));
        register(context, IRON_ORE_C0_0_14A_KEY, registryLookup.method_46747(ConfiguredFeatureInit.IRON_ORE_C0_0_14A_KEY),
                Modifiers.modifiersCount(10, class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(72))));
        register(context, IRON_ORE_1_14_KEY, registryLookup.method_46747(ConfiguredFeatureInit.IRON_ORE_1_14_KEY),
                Modifiers.modifiersCount(10, class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(72))));
        register(context, IRON_ORE_1_14_1_KEY, registryLookup.method_46747(ConfiguredFeatureInit.IRON_ORE_1_14_1_KEY),
                Modifiers.modifiersCount(10, class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(72))));
        register(context, GOLD_ORE_C0_0_14A_KEY, registryLookup.method_46747(ConfiguredFeatureInit.GOLD_ORE_C0_0_14A_KEY),
                Modifiers.modifiersCount(8, class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(32))));
        register(context, GOLD_ORE_C0_26ST_KEY, registryLookup.method_46747(ConfiguredFeatureInit.GOLD_ORE_C0_26ST_KEY),
                Modifiers.modifiersCount(8, class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(32))));
        register(context, GOLD_ORE_1_14_KEY, registryLookup.method_46747(ConfiguredFeatureInit.GOLD_ORE_1_14_KEY),
                Modifiers.modifiersCount(8, class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(32))));

        register(context, DANDELION_C0_0_20A_KEY, registryLookup.method_46747(ConfiguredFeatureInit.DANDELION_C0_0_20A_KEY),
                List.of(class_6658.method_39618(class_6646.method_38883())));
        register(context, DANDELION_C0_0_20A_PATCH_KEY, registryLookup.method_46747(ConfiguredFeatureInit.DANDELION_C0_0_20A_PATCH_KEY),
                List.of(class_6799.method_39659(32), class_5450.method_39639(), class_6817.field_36078, class_6792.method_39614()));
        register(context, ROSE_C0_0_20A_KEY, registryLookup.method_46747(ConfiguredFeatureInit.ROSE_C0_0_20A_KEY),
                List.of(class_6658.method_39618(class_6646.method_38883())));
        register(context, ROSE_C0_0_20A_PATCH_KEY, registryLookup.method_46747(ConfiguredFeatureInit.ROSE_C0_0_20A_PATCH_KEY),
                List.of(class_6799.method_39659(32), class_5450.method_39639(), class_6817.field_36078, class_6792.method_39614()));
        register(context, POPPY_1_7_KEY, registryLookup.method_46747(ConfiguredFeatureInit.POPPY_1_7_KEY),
                List.of(class_6658.method_39618(class_6646.method_38883())));
        register(context, POPPY_1_7_PATCH_KEY, registryLookup.method_46747(ConfiguredFeatureInit.POPPY_1_7_PATCH_KEY),
                List.of(class_6799.method_39659(32), class_5450.method_39639(), class_6817.field_36078, class_6792.method_39614()));
        register(context, BROWN_MUSHROOM_C0_0_20A_KEY, registryLookup.method_46747(ConfiguredFeatureInit.BROWN_MUSHROOM_C0_0_20A_KEY),
                List.of(class_6658.method_39618(class_6646.method_38883())));
        register(context, BROWN_MUSHROOM_C0_0_20A_PATCH_KEY, registryLookup.method_46747(ConfiguredFeatureInit.BROWN_MUSHROOM_C0_0_20A_PATCH_KEY),
                List.of(class_6799.method_39659(32), class_5450.method_39639(), class_6817.field_36078, class_6792.method_39614()));
        register(context, RED_MUSHROOM_C0_0_20A_KEY, registryLookup.method_46747(ConfiguredFeatureInit.RED_MUSHROOM_C0_0_20A_KEY),
                List.of(class_6658.method_39618(class_6646.method_38883())));
        register(context, RED_MUSHROOM_C0_0_20A_PATCH_KEY, registryLookup.method_46747(ConfiguredFeatureInit.RED_MUSHROOM_C0_0_20A_PATCH_KEY),
                List.of(class_6799.method_39659(32), class_5450.method_39639(), class_6817.field_36078, class_6792.method_39614()));
    }

    private static class_5321<class_6796> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41245, Blocktopia.id(name));
    }

    private static void register(class_7891<class_6796> context,
                                 class_5321<class_6796> key,
                                 class_6880<class_2975<?, ?>> config,
                                 List<class_6797> modifiers) {
        context.method_46838(key, new class_6796(config, List.copyOf(modifiers)));
    }

    public static class Modifiers {
        public static List<class_6797> modifiers(class_6797 countModifier, class_6797 heightModifier) {
            return List.of(countModifier, class_5450.method_39639(), heightModifier, class_6792.method_39614());
        }

        public static List<class_6797> modifiersCount(int count, class_6797 heightModifier) {
            return modifiers(class_6793.method_39623(count), heightModifier);
        }

        public static List<class_6797> modifiersRarity(int chance, class_6797 heightModifier) {
            return modifiers(class_6799.method_39659(chance), heightModifier);
        }
    }
}
