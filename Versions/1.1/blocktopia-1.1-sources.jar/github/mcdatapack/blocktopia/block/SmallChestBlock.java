package github.mcdatapack.blocktopia.block;

import github.mcdatapack.blocktopia.block.entity.SmallChestBlockEntity;
import github.mcdatapack.blocktopia.init.BlockEntityTypeInit;
import net.minecraft.block.*;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;

public class SmallChestBlock extends class_2248 implements class_2343 {
    public static class_265 DefaultShape() {
        return class_259.method_17786(
                class_259.method_1081(0.125, 0.0625, 0.125, 0.875, 0.5625, 0.1875),
                class_259.method_1081(0.125, 0.5625, 0.125, 0.875, 0.75, 0.875),
                class_259.method_1081(0.4375, 0.5, 0.0625, 0.5625, 0.6875, 0.125),
                class_259.method_1081(0.125, 0.0625, 0.8125, 0.875, 0.5625, 0.875),
                class_259.method_1081(0.125, 0.0625, 0.1875, 0.1875, 0.5625, 0.8125),
                class_259.method_1081(0.8125, 0.0625, 0.1875, 0.875, 0.5625, 0.8125),
                class_259.method_1081(0.125, 0, 0.125, 0.875, 0.0625, 0.875)
        ).method_1097();
    }
    public static final class_2753 FACING = class_2741.field_12481;
    public static final Map<class_2350, class_265> Shapes = new HashMap<>();

    public SmallChestBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9564().method_11657(FACING, class_2350.field_11043));
        for (class_2350 direction : class_2350.values()) {
            Shapes.put(direction, calculateShapes(direction, DefaultShape()));
        }
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 view, class_2338 pos, class_3726 context) {
        return Shapes.get(state.method_11654(FACING));
    }


    private static class_265 calculateShapes(class_2350 to, class_265 shape) {
        final class_265[] buffer = {shape, class_259.method_1073()};

        final int times = (to.method_10161() - class_2350.field_11043.method_10161() + 4) % 4;
        for (int i = 0; i < times; i++) {
            buffer[0].method_1089((minX, minY, minZ, maxX, maxY, maxZ) ->
                    buffer[1] = class_259.method_1084(buffer[1],
                            class_259.method_1081(1 - maxZ, minY, minX, 1 - minZ, maxY, maxX)));
            buffer[0] = buffer[1];
            buffer[1] = class_259.method_1073();
        }

        return buffer[0];
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (!world.field_9236) {
            if (world.method_8321(pos) instanceof SmallChestBlockEntity smallChestBlockEntity) {
                player.method_17355(smallChestBlockEntity);
            }
        }

        return class_1269.method_29236(world.field_9236);
    }

    @Override
    @Nullable
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return BlockEntityTypeInit.SMALL_CHEST_BLOCK_ENTITY.method_11032(pos, state);
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11455;
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }

    @Override
    protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(FACING);
    }
}
