package github.mcdatapack.blocktopia.renderer;

import github.mcdatapack.blocktopia.block.SmallChestBlock;
import github.mcdatapack.blocktopia.block.entity.SmallChestBlockEntity;
import github.mcdatapack.blocktopia.models.SmallChestModel;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_630;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_827;

public class SmallChestBlockEntityRenderer implements class_827<SmallChestBlockEntity> {
    private static final List<ItemTransformation> TRANSFORMATIONS = new ArrayList<>();

    static {
        Random random = ThreadLocalRandom.current();
        for (int index = 0; index < 36; index++) {
            TRANSFORMATIONS.add(new ItemTransformation(
                    (random.nextDouble() - 0.5) * 0.4375,
                    (random.nextDouble() - 0.5) * 0.4375,
                    random.nextInt(360))
            );
        }
    }

    private final class_5614.class_5615 context;
    private final SmallChestModel model;

    public SmallChestBlockEntityRenderer(class_5614.class_5615 context) {
        this.context = context;
        this.model = new SmallChestModel(context.method_32140(SmallChestModel.LAYER));
    }

    @Override
    public void render(SmallChestBlockEntity entity, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) {
        matrices.method_22903();
        matrices.method_46416(0.5F, 0, 0.5F);
        class_630 lid = this.model.getLid();
        int defaultAngle = 0;
        int numPlayersOpen = entity.getNumPlayersOpen();
        float lidAngle = entity.getLidAngle();
        double maxAngle = Math.toRadians(110);
        if (numPlayersOpen > 0 && lidAngle < maxAngle) {
            lid.field_3654 = class_3532.method_16439(tickDelta/12, lidAngle, (float) maxAngle);
        }
        else if (numPlayersOpen == 0 && lidAngle > defaultAngle) {
            lid.field_3654 = class_3532.method_16439(tickDelta/12, lidAngle, defaultAngle);
        }
        entity.lidAngle = lid.field_3654;

        matrices.method_22907(class_7833.field_40716.rotationDegrees(switch (entity.method_11010().method_11654(SmallChestBlock.FACING)) {
            case field_11034 -> 270;
            case field_11035 -> 180;
            case field_11039 -> 90;
            default -> 0;
        }));




        if(entity.lidAngle > 0.1) {
            class_1277 inventory = entity.getInventory();
            class_1937 world = entity.method_10997();

            for (int i = 0; i < inventory.method_54454().size(); i++) {
                class_1799 stack = inventory.method_5438(i);
                if(stack.method_7960()) continue;

                ItemTransformation transformation = TRANSFORMATIONS.get(i);

                matrices.method_22903();
                matrices.method_22904(transformation.x(), 0.5, transformation.z());
                matrices.method_22905(0.325F, 0.325F, 0.325F);
                matrices.method_22907(class_7833.field_40716.rotationDegrees(transformation.rotation()));

                this.context.method_43335().method_23178(stack, class_811.field_4319,
                        light, overlay,
                        matrices, vertexConsumers,
                        world, 0);

                matrices.method_22909();
            }
        }

        this.model.method_60879(matrices, vertexConsumers.getBuffer(class_1921.method_23572(SmallChestModel.TEXTURE_LOCATION)), light, overlay);
        lid.field_3654 = defaultAngle;
        matrices.method_22909();
    }
    public record ItemTransformation(double x, double z, int rotation) {}
}
