package github.mcdatapack.blocktopia.villager;

import com.google.common.collect.ImmutableSet;
import github.mcdatapack.blocktopia.Blocktopia;
import github.mcdatapack.blocktopia.init.blocks.LegacyBlocks;
import net.fabricmc.fabric.api.object.builder.v1.world.poi.PointOfInterestHelper;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3852;
import net.minecraft.class_4158;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;


public class CustomVillager {
    public static final class_5321<class_4158> LEGACY_KEY = poiKey("legacy");
    public static final class_4158 LEGACY_POI = registerPoi("legacy", LegacyBlocks.CRAFTING_TABLE_IN20100131);
    public static final class_3852 LEGACY = registerProfession("legacy", LEGACY_KEY, class_3417.field_20680);

    public static final class_5321<class_4158> BEEKEEPER_KEY = poiKey("beekeeper");
    public static final class_4158 BEEKEEPER_POI = registerPoi("beekeeper", class_2246.field_42750);
    public static final class_3852 BEEKEEPER = registerProfession("beekeeper", BEEKEEPER_KEY, class_3417.field_20673);

    public static class_3852 registerProfession(String name, class_5321<class_4158> type, class_3414 soundEvent) {
        return class_2378.method_10230(class_7923.field_41195, Blocktopia.id(name),
                new class_3852(name, entry -> entry.method_40225(type), entry -> entry.method_40225(type),
                        ImmutableSet.of(), ImmutableSet.of(), soundEvent));
    }

    public static class_4158 registerPoi(String name, class_2248 block) {
        return PointOfInterestHelper.register(Blocktopia.id(name), 1, 10, block);
    }

    public static class_5321<class_4158> poiKey(String name) {
        return class_5321.method_29179(class_7924.field_41212, Blocktopia.id(name));
    }

    public static void load() {}
}
