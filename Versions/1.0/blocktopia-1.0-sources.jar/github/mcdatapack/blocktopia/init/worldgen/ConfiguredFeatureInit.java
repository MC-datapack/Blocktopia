package github.mcdatapack.blocktopia.init.worldgen;

import github.mcdatapack.blocktopia.Blocktopia;
import static github.mcdatapack.blocktopia.init.blocks.BlockInit.*;
import static github.mcdatapack.blocktopia.init.blocks.LegacyBlocks.*;

import github.mcdatapack.blocktopia.init.blocks.LegacyBlocks;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_3124;
import net.minecraft.class_3175;
import net.minecraft.class_3481;
import net.minecraft.class_3798;
import net.minecraft.class_3825;
import net.minecraft.class_4638;
import net.minecraft.class_4643;
import net.minecraft.class_4645;
import net.minecraft.class_4646;
import net.minecraft.class_4651;
import net.minecraft.class_4656;
import net.minecraft.class_5139;
import net.minecraft.class_5140;
import net.minecraft.class_5204;
import net.minecraft.class_5321;
import net.minecraft.class_6016;
import net.minecraft.class_6796;
import net.minecraft.class_7871;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.world.gen.feature.*;
import java.util.List;

public class ConfiguredFeatureInit {
    public static final class_5321<class_2975<?, ?>> PALM_TREE_KEY = registerKey("palm_tree");
    //Legacy
    public static final class_5321<class_2975<?, ?>> COAL_ORE_C0_0_14A_KEY = registerKey("coal_ore_c0_0_14a");
    public static final class_5321<class_2975<?, ?>> COAL_ORE_1_14_KEY = registerKey("coal_ore_1_14");
    public static final class_5321<class_2975<?, ?>> IRON_ORE_C0_0_14A_KEY = registerKey("iron_ore_c0_0_14a");
    public static final class_5321<class_2975<?, ?>> IRON_ORE_1_14_KEY = registerKey("iron_ore_1_14");
    public static final class_5321<class_2975<?, ?>> IRON_ORE_1_14_1_KEY = registerKey("iron_ore_1_14_4");
    public static final class_5321<class_2975<?, ?>> GOLD_ORE_C0_0_14A_KEY = registerKey("gold_ore_c0_0_14a");
    public static final class_5321<class_2975<?, ?>> GOLD_ORE_C0_26ST_KEY = registerKey("gold_ore_c0_26st");
    public static final class_5321<class_2975<?, ?>> GOLD_ORE_1_14_KEY = registerKey("gold_ore_1_14");
    public static final class_5321<class_2975<?, ?>> TREE_C0_24ST_KEY = registerKey("tree_c0_24st");
    public static final class_5321<class_2975<?, ?>> DANDELION_C0_0_20A_KEY = registerKey("dandelion_c0_0_20a");
    public static final class_5321<class_2975<?, ?>> DANDELION_C0_0_20A_PATCH_KEY = registerKey("dandelion_c0_0_20a_patch");
    public static final class_5321<class_2975<?, ?>> ROSE_C0_0_20A_KEY = registerKey("rose_c0_0_20a");
    public static final class_5321<class_2975<?, ?>> ROSE_C0_0_20A_PATCH_KEY = registerKey("rose_c0_0_20a_patch");
    public static final class_5321<class_2975<?, ?>> POPPY_1_7_KEY = registerKey("poppy_1_7");
    public static final class_5321<class_2975<?, ?>> POPPY_1_7_PATCH_KEY = registerKey("poppy_1_7_patch");
    public static final class_5321<class_2975<?, ?>> BROWN_MUSHROOM_C0_0_20A_KEY = registerKey("brown_mushroom_c0_0_20a");
    public static final class_5321<class_2975<?, ?>> BROWN_MUSHROOM_C0_0_20A_PATCH_KEY = registerKey("brown_mushroom_c0_0_20a_patch");
    public static final class_5321<class_2975<?, ?>> RED_MUSHROOM_C0_0_20A_KEY = registerKey("red_mushroom_c0_0_20a");
    public static final class_5321<class_2975<?, ?>> RED_MUSHROOM_C0_0_20A_PATCH_KEY = registerKey("red_mushroom_c0_0_20a_patch");


    public static void bootstrap(class_7891<class_2975<?, ?>> context) {
        class_7871<class_6796> registryLookup = context.method_46799(class_7924.field_41245);
        class_3825 overworldOreReplaceables = new class_3798(class_3481.field_28992);

        register(context, PALM_TREE_KEY, class_3031.field_24134, new class_4643.class_4644(
                class_4656.method_38432(PALM_LOG),
                new class_5139(4, 4, 6),
                class_4656.method_38432(PALM_LEAVES),
                new class_4645(class_6016.method_34998(4), class_6016.method_34998(0)),
                new class_5204(4, 1, 4)
        ).method_23445());

        register(context, DANDELION_C0_0_20A_KEY, class_3031.field_13518, new class_3175(
                class_4651.method_38432(DANDELION_C0_0_20A)
        ));
        register(context, DANDELION_C0_0_20A_PATCH_KEY, class_3031.field_21219, new class_4638(
                32, 10, 5, registryLookup.method_46747(PlacedFeatureInit.DANDELION_C0_0_20A_KEY)
        ));
        register(context, ROSE_C0_0_20A_KEY, class_3031.field_13518, new class_3175(
                class_4651.method_38432(ROSE_C0_0_20A)
        ));
        register(context, ROSE_C0_0_20A_PATCH_KEY, class_3031.field_21219, new class_4638(
                32, 10, 5, registryLookup.method_46747(PlacedFeatureInit.ROSE_C0_0_20A_KEY)
        ));
        register(context, POPPY_1_7_KEY, class_3031.field_13518, new class_3175(
                class_4651.method_38432(POPPY_1_7)
        ));
        register(context, POPPY_1_7_PATCH_KEY, class_3031.field_21219, new class_4638(
                32, 10, 5, registryLookup.method_46747(PlacedFeatureInit.POPPY_1_7_KEY)
        ));
        register(context, BROWN_MUSHROOM_C0_0_20A_KEY, class_3031.field_13518, new class_3175(
                class_4651.method_38432(BROWN_MUSHROOM_C0_0_20A)
        ));
        register(context, BROWN_MUSHROOM_C0_0_20A_PATCH_KEY, class_3031.field_21219, new class_4638(
                32, 10, 5, registryLookup.method_46747(PlacedFeatureInit.BROWN_MUSHROOM_C0_0_20A_KEY)
        ));
        register(context, RED_MUSHROOM_C0_0_20A_KEY, class_3031.field_13518, new class_3175(
                class_4651.method_38432(RED_MUSHROOM_C0_0_20A)
        ));
        register(context, RED_MUSHROOM_C0_0_20A_PATCH_KEY, class_3031.field_21219, new class_4638(
                32, 10, 5, registryLookup.method_46747(PlacedFeatureInit.RED_MUSHROOM_C0_0_20A_KEY)
        ));


        register(context, TREE_C0_24ST_KEY, class_3031.field_24134, new class_4643.class_4644(
                class_4656.method_38432(LOG_C0_0_14A),
                new class_5140(4, 2, 0),
                class_4656.method_38432(LEAVES_C0_24ST),
                new class_4646(class_6016.method_34998(2), class_6016.method_34998(0), 3),
                new class_5204(1, 0, 1)
        ).method_23445());

        List<class_3124.class_5876> overworldTargetsCoal_C0_0_14A = List.of(
                class_3124.method_33994(overworldOreReplaceables, COAL_ORE_C0_0_14A.method_9564()));
        List<class_3124.class_5876> overworldTargetsCoal_1_14 = List.of(
                class_3124.method_33994(overworldOreReplaceables, COAL_ORE_1_14.method_9564()));
        List<class_3124.class_5876> overworldTargetsIron_C0_0_14A = List.of(
                class_3124.method_33994(overworldOreReplaceables, IRON_ORE_C0_0_14A.method_9564()));
        List<class_3124.class_5876> overworldTargetsIron_1_14 = List.of(
            class_3124.method_33994(overworldOreReplaceables, IRON_ORE_1_14.method_9564()));
        List<class_3124.class_5876> overworldTargetsIron_1_14_1 = List.of(
            class_3124.method_33994(overworldOreReplaceables, IRON_ORE_1_14_1.method_9564()));
        List<class_3124.class_5876> overworldTargetsGold_C0_0_14A = List.of(
                class_3124.method_33994(overworldOreReplaceables, GOLD_ORE_C0_0_14A.method_9564()));
        List<class_3124.class_5876> overworldTargetsGold_C0_24ST = List.of(
                class_3124.method_33994(overworldOreReplaceables, GOLD_ORE_C0_26ST.method_9564()));
        List<class_3124.class_5876> overworldTargetsGold_1_14 = List.of(
                class_3124.method_33994(overworldOreReplaceables, GOLD_ORE_1_14.method_9564()));

        register(context, COAL_ORE_C0_0_14A_KEY, class_3031.field_13517, new class_3124(overworldTargetsCoal_C0_0_14A, 17, 0));
        register(context, COAL_ORE_1_14_KEY, class_3031.field_13517, new class_3124(overworldTargetsCoal_1_14, 17, 0));
        register(context, IRON_ORE_C0_0_14A_KEY, class_3031.field_13517, new class_3124(overworldTargetsIron_C0_0_14A, 9, 0));
        register(context, IRON_ORE_1_14_KEY, class_3031.field_13517, new class_3124(overworldTargetsIron_1_14, 9, 0));
        register(context, IRON_ORE_1_14_1_KEY, class_3031.field_13517, new class_3124(overworldTargetsIron_1_14_1, 9, 0));
        register(context, GOLD_ORE_C0_0_14A_KEY, class_3031.field_13517, new class_3124(overworldTargetsGold_C0_0_14A, 9, 0));
        register(context, GOLD_ORE_C0_26ST_KEY, class_3031.field_13517, new class_3124(overworldTargetsGold_C0_24ST, 9, 0));
        register(context, GOLD_ORE_1_14_KEY, class_3031.field_13517, new class_3124(overworldTargetsGold_1_14, 9, 0));
    }

    private static class_5321<class_2975<?, ?>> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41239, Blocktopia.id(name));
    }

    private static <FC extends class_3037, F extends class_3031<FC>> void register(class_7891<class_2975<?, ?>> context,
                                                                                   class_5321<class_2975<?, ?>> key,
                                                                                   F feature, FC featureConfig) {
        context.method_46838(key, new class_2975<>(feature, featureConfig));
    }
}
