package github.mcdatapack.blocktopia.init;

import github.mcdatapack.blocktopia.Blocktopia;
import github.mcdatapack.blocktopia.init.blocks.BlockInit;
import github.mcdatapack.blocktopia.init.blocks.LegacyBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_2246;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_7923;

@SuppressWarnings("unused")
public class ItemGroupInit {
    public static final class_1761 GRAVITY_BLOCKS_GROUP = register("gravity_blocks_group", FabricItemGroup.builder()
            .method_47321(class_2561.method_43471("itemGroup.blocktopia.gravity_blocks"))
            .method_47320(BlockInit.PAPER_BLOCK.method_8389()::method_7854)
            .method_47317((displayContext, entries) -> {
                entries.method_45421(class_2246.field_10102);
                entries.method_45421(LegacyBlocks.SAND_C0_0_14A);
                entries.method_45421(LegacyBlocks.SAND_C0_0_15A);
                entries.method_45421(LegacyBlocks.SAND_B1_9PRE6);
                entries.method_45421(class_2246.field_42728);
                entries.method_45421(class_2246.field_10255);
                entries.method_45421(LegacyBlocks.GRAVEL_C0_0_14A);
                entries.method_45421(LegacyBlocks.GRAVEL_C0_0_15A);
                entries.method_45421(LegacyBlocks.GRAVEL_B1_9PRE5);
                entries.method_45421(LegacyBlocks.GRAVEL_1_3);
                entries.method_45421(class_2246.field_43227);
                entries.method_45421(class_2246.field_10197);
                entries.method_45421(class_2246.field_10628);
                entries.method_45421(class_2246.field_10353);
                entries.method_45421(class_2246.field_10506);
                entries.method_45421(class_2246.field_10023);
                entries.method_45421(class_2246.field_10404);
                entries.method_45421(class_2246.field_10300);
                entries.method_45421(class_2246.field_10522);
                entries.method_45421(class_2246.field_10287);
                entries.method_45421(class_2246.field_10022);
                entries.method_45421(class_2246.field_10145);
                entries.method_45421(class_2246.field_10133);
                entries.method_45421(class_2246.field_10529);
                entries.method_45421(class_2246.field_10233);
                entries.method_45421(class_2246.field_10321);
                entries.method_45421(class_2246.field_10456);
                entries.method_45421(class_2246.field_10535);
                entries.method_45421(class_2246.field_10414);
                entries.method_45421(class_2246.field_10105);
                entries.method_45421(BlockInit.PAPER_BLOCK);
                entries.method_45421(BlockInit.GUNPOWDER_BLOCK);
                entries.method_45421(BlockInit.FIREWORK_BLOCK);
            }).method_47324());

        public static final class_1761 LEGACY_BLOCKS_GROUP = register("legacy_blocks_group", FabricItemGroup.builder()
                .method_47321(class_2561.method_43471("itemGroup.blocktopia.legacy_blocks"))
                .method_47320(LegacyBlocks.COBBLESTONE_RD20090515.method_8389()::method_7854)
                .method_47317((displayContext, entries) -> {
                    entries.method_45421(LegacyBlocks.COBBLESTONE_RD20090515);
                    entries.method_45421(LegacyBlocks.COBBLESTONE_C_0_0_14A);
                    entries.method_45421(LegacyBlocks.COBBLESTONE_B1_7);
                    entries.method_45421(LegacyBlocks.WOODEN_PLANKS_RD20090515);
                    entries.method_45421(LegacyBlocks.WOODEN_PLANKS_RD161348);
                    entries.method_45421(LegacyBlocks.WOODEN_PLANKS_C0_0_14A);
                    entries.method_45421(LegacyBlocks.WOODEN_PLANKS_C0_0_15A);
                    entries.method_45421(LegacyBlocks.WOODEN_PLANKS_B1_9PRE5);
                    entries.method_45421(LegacyBlocks.SAPLING_RD161348);
                    entries.method_45421(LegacyBlocks.SAPLING_C0_0_13A);
                    entries.method_45421(LegacyBlocks.SAPLING_C0_24ST);
                    entries.method_45421(LegacyBlocks.BEDROCK_C0_0_12A);
                    entries.method_45421(LegacyBlocks.SAND_C0_0_14A);
                    entries.method_45421(LegacyBlocks.SAND_C0_0_15A);
                    entries.method_45421(LegacyBlocks.SAND_B1_9PRE6);
                    entries.method_45421(LegacyBlocks.GRAVEL_C0_0_14A);
                    entries.method_45421(LegacyBlocks.GRAVEL_C0_0_15A);
                    entries.method_45421(LegacyBlocks.GRAVEL_B1_9PRE5);
                    entries.method_45421(LegacyBlocks.GRAVEL_1_3);
                    entries.method_45421(LegacyBlocks.COAL_ORE_C0_0_14A);
                    entries.method_45421(LegacyBlocks.COAL_ORE_1_14);
                    entries.method_45421(LegacyBlocks.IRON_ORE_C0_0_14A);
                    entries.method_45421(LegacyBlocks.IRON_ORE_1_14);
                    entries.method_45421(LegacyBlocks.IRON_ORE_1_14_1);
                    entries.method_45421(LegacyBlocks.GOLD_ORE_C0_0_14A);
                    entries.method_45421(LegacyBlocks.GOLD_ORE_C0_26ST);
                    entries.method_45421(LegacyBlocks.GOLD_ORE_1_14);
                    entries.method_45421(LegacyBlocks.LOG_C0_0_14A);
                    entries.method_45421(LegacyBlocks.LEAVES_C0_0_14A);
                    entries.method_45421(LegacyBlocks.LEAVES_C0_0_15A);
                    entries.method_45421(LegacyBlocks.LEAVES_C0_24ST);
                    entries.method_45421(LegacyBlocks.SPONGE_C0_0_19A);
                    entries.method_45421(LegacyBlocks.SPONGE_1_8);
                    entries.method_45421(LegacyBlocks.WET_SPONGE_1_8);
                    entries.method_45421(LegacyBlocks.GLASS_C0_0_19A);
                    entries.method_45421(LegacyBlocks.WHITE_CLOTH);
                    entries.method_45421(LegacyBlocks.LIGHT_GRAY_CLOTH_C0_0_20A);
                    entries.method_45421(LegacyBlocks.LIGHT_GRAY_CLOTH_C0_28A);
                    entries.method_45421(LegacyBlocks.DARK_GRAY_CLOTH_C0_0_20A);
                    entries.method_45421(LegacyBlocks.DARK_GRAY_CLOTH_C0_28A);
                    entries.method_45421(LegacyBlocks.RED_CLOTH);
                    entries.method_45421(LegacyBlocks.ORANGE_CLOTH);
                    entries.method_45421(LegacyBlocks.YELLOW_CLOTH);
                    entries.method_45421(LegacyBlocks.CHARTREUSE_CLOTH);
                    entries.method_45421(LegacyBlocks.SPRING_GREEN_CLOTH);
                    entries.method_45421(LegacyBlocks.CYAN_CLOTH);
                    entries.method_45421(LegacyBlocks.CAPRI_CLOTH);
                    entries.method_45421(LegacyBlocks.ULTRAMARINE_CLOTH);
                    entries.method_45421(LegacyBlocks.VIOLET_CLOTH);
                    entries.method_45421(LegacyBlocks.PURPLE_CLOTH);
                    entries.method_45421(LegacyBlocks.MAGENTA_CLOTH);
                    entries.method_45421(LegacyBlocks.ROSE_CLOTH);
                    entries.method_45421(LegacyBlocks.GOLD_BLOCK_C0_0_20A);
                    entries.method_45421(LegacyBlocks.GOLD_BLOCK_C0_26ST);
                    entries.method_45421(LegacyBlocks.GOLD_BLOCK_A1_2_0);
                    entries.method_45421(LegacyBlocks.GOLD_BLOCK_B1_9PRE5);
                    entries.method_45421(LegacyBlocks.DANDELION_C0_0_20A);
                    entries.method_45421(LegacyBlocks.ROSE_C0_0_20A);
                    entries.method_45421(LegacyBlocks.POPPY_1_7);
                    entries.method_45421(LegacyBlocks.RED_MUSHROOM_C0_0_20A);
                    entries.method_45421(LegacyBlocks.BROWN_MUSHROOM_C0_0_20A);
                    entries.method_45421(LegacyBlocks.STONE_SLAB_C0_26ST);
                    entries.method_45421(LegacyBlocks.IRON_BLOCK_C0_26ST);
                    entries.method_45421(LegacyBlocks.IRON_BLOCK_A1_2_0);
                    entries.method_45421(LegacyBlocks.IRON_BLOCK_B1_9PRE5);
                    entries.method_45421(LegacyBlocks.TNT_C0_26ST);
                    entries.method_45421(LegacyBlocks.TNT_C0_28A);
                    entries.method_45421(LegacyBlocks.MOSSY_COBBLESTONE_C0_26ST);
                    entries.method_45421(LegacyBlocks.MOSSY_COBBLESTONE_B1_8);
                    entries.method_45421(LegacyBlocks.BRICKS_C0_26ST);
                    entries.method_45421(LegacyBlocks.BRICKS_A1_0_11);
                    entries.method_45421(LegacyBlocks.BOOKSHELF_C0_26ST);
                    entries.method_45421(LegacyBlocks.BOOKSHELF_B1_9PRE5);
                    entries.method_45421(LegacyBlocks.OBSIDIAN_C0_28A);
                    entries.method_45421(ItemInit.TORCH_IN20100124_2);
                    entries.method_45421(LegacyBlocks.DIAMOND_ORE_IN20100128);
                    entries.method_45421(LegacyBlocks.DIAMOND_ORE_1_14);
                    entries.method_45421(LegacyBlocks.DIAMOND_BLOCK_IN20100128);
                    entries.method_45421(LegacyBlocks.DIAMOND_BLOCK_A1_2_0);
                    entries.method_45421(LegacyBlocks.DIAMOND_BLOCK_B1_9PRE5);
                    entries.method_45421(LegacyBlocks.CRAFTING_TABLE_IN20100131);
                    entries.method_45421(LegacyBlocks.CRAFTING_TABLE_1_14);
                    entries.method_45421(LegacyBlocks.FURNACE_IN20100219);
                    entries.method_45421(LegacyBlocks.LIT_FURNACE_IN20100219);
                    entries.method_45421(LegacyBlocks.FURNACE_B1_2);
                    entries.method_45421(LegacyBlocks.LIT_FURNACE_B1_2);
                    entries.method_45421(LegacyBlocks.LADDER_INF20100607);
                    entries.method_45421(LegacyBlocks.LADDER_INF20100618);
                    entries.method_45421(ItemInit.SIGN_INF20100607);
                    entries.method_45421(LegacyBlocks.WOODEN_DOOR_INF20100607);
                    entries.method_45421(LegacyBlocks.WOODEN_STAIRS_RD20090515);
                    entries.method_45421(LegacyBlocks.WOODEN_STAIRS_RD161348);
                    entries.method_45421(LegacyBlocks.WOODEN_STAIRS_C0_0_14A);
                    entries.method_45421(LegacyBlocks.WOODEN_STAIRS_INF20100629);
                    entries.method_45421(LegacyBlocks.WOODEN_STAIRS_B1_9PRE5);
                    entries.method_45421(LegacyBlocks.COBBLESTONE_STAIRS_RD20090515);
                    entries.method_45421(LegacyBlocks.COBBLESTONE_STAIRS_C0_0_14A);
                    entries.method_45421(LegacyBlocks.COBBLESTONE_STAIRS_B1_7);
                    entries.method_45421(LegacyBlocks.REDSTONE_ORE_A1_0_1);
                    entries.method_45421(LegacyBlocks.REDSTONE_ORE_1_14);
                    entries.method_45421(ItemInit.REDSTONE_TORCH_A1_0_1);
                    entries.method_45421(LegacyBlocks.SNOW_A1_0_4);
                    entries.method_45421(LegacyBlocks.ICE_A1_0_4);
                    entries.method_45421(LegacyBlocks.SNOW_BLOCK_A1_0_5);
                    entries.method_45421(LegacyBlocks.WOODEN_FENCE_RD20090515);
                    entries.method_45421(LegacyBlocks.WOODEN_FENCE_RD161348);
                    entries.method_45421(LegacyBlocks.WOODEN_FENCE_C0_0_14A);
                    entries.method_45421(LegacyBlocks.WOODEN_FENCE_A1_0_17);
                    entries.method_45421(LegacyBlocks.WOODEN_FENCE_B1_9PRE5);
                    entries.method_45421(LegacyBlocks.NETHERRACK_A1_2_0);
                    entries.method_45421(LegacyBlocks.NETHERRACK_B1_9PRE5);
                    entries.method_45421(LegacyBlocks.SOUL_SAND_A1_2_0);
                    entries.method_45421(LegacyBlocks.GLOWSTONE_A1_2_0);
                    entries.method_45421(LegacyBlocks.GLOWSTONE_B1_9PRE5);
                    entries.method_45421(LegacyBlocks.CARVED_PUMPKIN_A1_2_0);
                    entries.method_45421(LegacyBlocks.JACK_O_LANTERN_A1_2_0);
            }).method_47324());

    public static final class_1761 NATURAL_BLOCKS_GROUP = register("natural_blocks_group", FabricItemGroup.builder()
            .method_47321(class_2561.method_43471("itemGroup.blocktopia.natural_blocks"))
            .method_47320(BlockInit.PALM_LEAVES.method_8389()::method_7854)
            .method_47317((displayContext, entries) -> {
                entries.method_45421(BlockInit.PALM_WOOD);
                entries.method_45421(BlockInit.STRIPPED_PALM_WOOD);
                entries.method_45421(BlockInit.PALM_LOG);
                entries.method_45421(BlockInit.STRIPPED_PALM_LOG);
                entries.method_45421(BlockInit.PALM_LEAVES);
                entries.method_45421(BlockInit.PALM_SAPLING);
                entries.method_45421(BlockInit.PALM_PLANKS);
                entries.method_45421(BlockInit.PALM_STAIRS);
                entries.method_45421(BlockInit.PALM_SLAB);
                entries.method_45421(BlockInit.PALM_FENCE);
                entries.method_45421(BlockInit.PALM_FENCE_GATE);
                entries.method_45421(BlockInit.PALM_PRESSURE_PLATE);
                entries.method_45421(BlockInit.PALM_BUTTON);
                entries.method_45421(BlockInit.PALM_DOOR);
                entries.method_45421(BlockInit.PALM_TRAPDOOR);
                entries.method_45421(ItemInit.PALM_SIGN);
                entries.method_45421(ItemInit.PALM_HANGING_SIGN);
                entries.method_45421(ItemInit.PALM_BOAT);
                entries.method_45421(ItemInit.PALM_CHEST_BOAT);
                entries.method_45421(ItemInit.COCONUT);
                entries.method_45421(LegacyBlocks.LEAVES_C0_0_14A);
                entries.method_45421(LegacyBlocks.LEAVES_C0_0_15A);
                entries.method_45421(LegacyBlocks.LEAVES_C0_24ST);
                entries.method_45421(LegacyBlocks.LOG_C0_0_14A);
                entries.method_45421(LegacyBlocks.SAPLING_RD161348);
                entries.method_45421(LegacyBlocks.SAPLING_C0_0_13A);
                entries.method_45421(LegacyBlocks.SAPLING_C0_24ST);
                entries.method_45421(LegacyBlocks.ROSE_C0_0_20A);
                entries.method_45421(LegacyBlocks.POPPY_1_7);
                entries.method_45421(LegacyBlocks.DANDELION_C0_0_20A);
                entries.method_45421(LegacyBlocks.RED_MUSHROOM_C0_0_20A);
                entries.method_45421(LegacyBlocks.BROWN_MUSHROOM_C0_0_20A);
            }).method_47324());

    public static final class_1761 OTHER_ITEMS_GROUP = register("other_items_group", FabricItemGroup.builder()
            .method_47321(class_2561.method_43471("itemGroup.blocktopia.other_items"))
            .method_47320(BlockInit.SMALL_CHEST.method_8389()::method_7854)
            .method_47317((displayContext, entries) -> {
                entries.method_45421(BlockInit.SMALL_CHEST);
                entries.method_45421(ItemInit.COCONUT);
                entries.method_45421(ItemInit.GOLDEN_COCONUT);
                entries.method_45421(ItemInit.ENCHANTED_GOLDEN_COCONUT);
                entries.method_45421(ItemInit.ENCHANTED_GOLDEN_CARROT);
                entries.method_45421(ItemInit.GOLDEN_POTATO);
                entries.method_45421(ItemInit.ENCHANTED_GOLDEN_POTATO);
                entries.method_45421(ItemInit.GOLDEN_BAKED_POTATO);
                entries.method_45421(ItemInit.ENCHANTED_GOLDEN_BAKED_POTATO);
                entries.method_45421(ItemInit.GIANT_SPAWN_EGG);
                entries.method_45421(ItemInit.ILLUSIONER_SPAWN_EGG);
            }).method_47324());


    public static <T extends class_1761> T register(String name, T itemGroup) {
        return class_2378.method_10230(class_7923.field_44687, Blocktopia.id(name), itemGroup);
    }

    public static void load() {}
}
