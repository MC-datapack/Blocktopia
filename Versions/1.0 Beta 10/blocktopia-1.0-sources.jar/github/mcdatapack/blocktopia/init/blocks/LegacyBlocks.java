package github.mcdatapack.blocktopia.init.blocks;

import com.mojang.serialization.MapCodec;
import github.mcdatapack.blocktopia.Blocktopia;
import github.mcdatapack.blocktopia.block.SpongeBlock_1_8;
import github.mcdatapack.blocktopia.block.WetSpongeBlock_1_8;
import github.mcdatapack.blocktopia.init.ItemInit;
import github.mcdatapack.blocktopia.init.worldgen.ConfiguredFeatureInit;
import github.mcdatapack.blocktopia.list.BlockSetTypeList;
import github.mcdatapack.blocktopia.list.FoodList;
import github.mcdatapack.blocktopia.sign.api.block.BlocktopiaSignBlock;
import github.mcdatapack.blocktopia.sign.api.block.BlocktopiaWallSignBlock;
import java.util.Optional;

import net.minecraft.block.*;
import net.minecraft.class_1294;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2276;
import net.minecraft.class_2323;
import net.minecraft.class_2346;
import net.minecraft.class_2350;
import net.minecraft.class_2354;
import net.minecraft.class_2356;
import net.minecraft.class_2362;
import net.minecraft.class_2378;
import net.minecraft.class_2381;
import net.minecraft.class_2397;
import net.minecraft.class_2398;
import net.minecraft.class_2399;
import net.minecraft.class_2431;
import net.minecraft.class_2449;
import net.minecraft.class_2458;
import net.minecraft.class_2459;
import net.minecraft.class_2465;
import net.minecraft.class_2473;
import net.minecraft.class_2482;
import net.minecraft.class_2488;
import net.minecraft.class_2492;
import net.minecraft.class_2498;
import net.minecraft.class_2502;
import net.minecraft.class_2510;
import net.minecraft.class_2527;
import net.minecraft.class_2530;
import net.minecraft.class_2555;
import net.minecraft.class_2766;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_6019;
import net.minecraft.class_7923;
import net.minecraft.class_8813;
import net.minecraft.class_8923;

import static net.minecraft.class_4970.class_2251.*;
import static net.minecraft.class_2246.*;
import static net.minecraft.class_1767.field_7964;

public class LegacyBlocks {
    public static final class_2248 COBBLESTONE_RD20090515 = register("cobblestone_rd20090515", method_9630(field_10445));
    public static final class_2248 COBBLESTONE_C_0_0_14A = register("cobblestone_c_0_0_14a", method_9630(field_10445));
    public static final class_2248 COBBLESTONE_B1_7 = register("cobblestone_b1_7", method_9630(field_10445));
    public static final class_2248 WOODEN_PLANKS_RD20090515 = register("wooden_planks_rd20090515", method_9630(field_10161));
    public static final class_2248 WOODEN_PLANKS_RD161348 = register("wooden_planks_rd161348", method_9630(field_10161));
    public static final class_2248 WOODEN_PLANKS_C0_0_14A = register("wooden_planks_c0_0_14a", method_9630(field_10161));
    public static final class_2248 WOODEN_PLANKS_C0_0_15A = register("wooden_planks_c0_0_15a", method_9630(field_10161));
    public static final class_2248 WOODEN_PLANKS_B1_9PRE5 = register("wooden_planks_b1_9pre5", method_9630(field_10161));
    public static final class_2248 LOG_C0_0_14A = register("log_c0_0_14a", createLogBlock(class_3620.field_15996, class_3620.field_15996));
    public static final class_2397 LEAVES_C0_0_14A = register("leaves_c0_0_14a", new class_2397(method_9630(field_10503)));
    public static final class_2397 LEAVES_C0_0_15A = register("leaves_c0_0_15a", new class_2397(method_9630(field_10503)));
    public static final class_2397 LEAVES_C0_24ST = register("leaves_c0_24st", new class_2397(method_9630(field_10503)));
    public static final class_2356 SAPLING_RD161348 = register("sapling_rd161348", new class_2356(class_1294.field_16595, 4.0F,
            method_9630(field_10394)));
    public static final class_2248 POTTED_SAPLING_RD161348 = register("potted_sapling_rd161348", createFlowerPotBlock(field_10394));
    public static final class_2356 SAPLING_C0_0_13A = register("sapling_c0_0_13a", new class_2356(class_1294.field_16595, 4.0F, method_9630(field_10394)));
    public static final class_2248 POTTED_SAPLING_C0_0_13A = register("potted_sapling_c0_0_13a", createFlowerPotBlock(SAPLING_C0_0_13A));
    public static final class_2473 SAPLING_C0_24ST = register("sapling_c0_24st", new class_2473(new class_8813(Blocktopia.id("sapling").toString(),
            0.1F,
            Optional.of(ConfiguredFeatureInit.TREE_C0_24ST_KEY), Optional.of(ConfiguredFeatureInit.TREE_C0_24ST_KEY),
            Optional.of(ConfiguredFeatureInit.TREE_C0_24ST_KEY), Optional.of(ConfiguredFeatureInit.TREE_C0_24ST_KEY),
            Optional.of(ConfiguredFeatureInit.TREE_C0_24ST_KEY), Optional.of(ConfiguredFeatureInit.TREE_C0_24ST_KEY)),
            method_9630(field_10394)));
    public static final class_2248 POTTED_SAPLING_C0_24ST = registerWithoutItem("potted_sapling_c0_24st", createFlowerPotBlock(SAPLING_C0_24ST));
    public static final class_2248 BEDROCK_C0_0_12A = register("bedrock_c0_0_12a", method_9630(field_9987));
    public static final class_2346 SAND_C0_0_14A = register("sand_c0_0_14a", new class_2346(method_9630(field_10102)) {
        @Override protected MapCodec<? extends class_2346> method_53969() {return null;}});
    public static final class_2346 SAND_C0_0_15A = register("sand_c0_0_15a", new class_2346(method_9630(field_10102)) {
        @Override protected MapCodec<? extends class_2346> method_53969() {return null;}});
    public static final class_2346 SAND_B1_9PRE6 = register("sand_b1_9pre6", new class_2346(method_9630(field_10102)) {
        @Override protected MapCodec<? extends class_2346> method_53969() {return null;}});
    public static final class_2346 GRAVEL_C0_0_14A = register("gravel_c0_0_14a", new class_2346(method_9630(field_10255)) {
        @Override protected MapCodec<? extends class_2346> method_53969() {return null;}});
    public static final class_2346 GRAVEL_C0_0_15A = register("gravel_c0_0_15a", new class_2346(method_9630(field_10255)) {
        @Override protected MapCodec<? extends class_2346> method_53969() {return null;}});
    public static final class_2346 GRAVEL_B1_9PRE5 = register("gravel_b1_9pre5", new class_2346(method_9630(field_10255)) {
        @Override protected MapCodec<? extends class_2346> method_53969() {return null;}});
    public static final class_2346 GRAVEL_1_3 = register("gravel_1_3", new class_2346(method_9630(field_10255)) {
        @Override protected MapCodec<? extends class_2346> method_53969() {return null;}});
    public static final class_2431 COAL_ORE_C0_0_14A = register("coal_ore_c0_0_14a", new class_2431(class_6019.method_35017(0, 2), method_9630(field_10418)));
    public static final class_2431 COAL_ORE_1_14 = register("coal_ore_1_14", new class_2431(class_6019.method_35017(0, 2), method_9630(field_10418)));
    public static final class_2248 IRON_ORE_C0_0_14A = register("iron_ore_c0_0_14a", method_9630(field_10212));
    public static final class_2248 IRON_ORE_1_14 = register("iron_ore_1_14", method_9630(field_10212));
    public static final class_2248 IRON_ORE_1_14_1 = register("iron_ore_1_14_1", method_9630(field_10212));
    public static final class_2248 GOLD_ORE_C0_0_14A = register("gold_ore_c0_0_14a", method_9630(field_10571));
    public static final class_2248 GOLD_ORE_C0_26ST = register("gold_ore_c0_26st", method_9630(field_10571));
    public static final class_2248 GOLD_ORE_1_14 = register("gold_ore_1_14", method_9630(field_10571));
    public static final class_2502 SPONGE_C0_0_19A = register("sponge_c0_0_19a", new class_2502(method_9630(field_10258)));
    public static final SpongeBlock_1_8 SPONGE_1_8 = register("sponge_1_8", new SpongeBlock_1_8(method_9630(field_10258)));
    public static final WetSpongeBlock_1_8 WET_SPONGE_1_8 = register("wet_sponge_1_8", new WetSpongeBlock_1_8(method_9630(field_10562)));
    public static final class_8923 GLASS_C0_0_19A = register("glass_c0_0_19a", new class_8923(method_9630(field_10033)));
    public static final class_2248 WHITE_CLOTH = register("withe_cloth", method_9630(field_10446));
    public static final class_2248 LIGHT_GRAY_CLOTH_C0_0_20A = register("light_gray_cloth_c0_0_20a", method_9630(field_10222));
    public static final class_2248 LIGHT_GRAY_CLOTH_C0_28A = register("light_gray_cloth_c0_28a", method_9630(field_10222));
    public static final class_2248 DARK_GRAY_CLOTH_C0_0_20A = register("dark_gray_cloth_c0_0_20a", method_9630(field_10423));
    public static final class_2248 DARK_GRAY_CLOTH_C0_28A = register("dark_gray_cloth_c0_28a", method_9630(field_10423));
    public static final class_2248 RED_CLOTH = register("red_cloth", method_9630(field_10314));
    public static final class_2248 ORANGE_CLOTH = register("orange_cloth", method_9630(field_10095));
    public static final class_2248 YELLOW_CLOTH = register("yellow_cloth", method_9630(field_10490));
    public static final class_2248 CHARTREUSE_CLOTH = register("chartreuse_cloth", method_9630(field_10028));
    public static final class_2248 SPRING_GREEN_CLOTH = register("spring_green_cloth", method_9630(field_10170));
    public static final class_2248 CYAN_CLOTH = register("cyan_cloth", method_9630(field_10619));
    public static final class_2248 CAPRI_CLOTH = register("capri_cloth", method_9630(field_10294));
    public static final class_2248 ULTRAMARINE_CLOTH = register("ultramarine_cloth", method_9630(field_10514));
    public static final class_2248 VIOLET_CLOTH = register("violet_cloth", method_9630(field_10259));
    public static final class_2248 PURPLE_CLOTH = register("purple_cloth", method_9630(field_10259));
    public static final class_2248 MAGENTA_CLOTH = register("magenta_cloth", method_9630(field_10215));
    public static final class_2248 ROSE_CLOTH = register("rose_cloth", method_9630(field_10459));
    public static final class_2248 GOLD_BLOCK_C0_0_20A = register("gold_block_c0_0_20a", method_9630(field_10205));
    public static final class_2248 GOLD_BLOCK_C0_26ST = register("gold_block_c0_26st", method_9630(field_10205));
    public static final class_2248 GOLD_BLOCK_A1_2_0 = register("gold_block_a1_2_0", method_9630(field_10205));
    public static final class_2248 GOLD_BLOCK_B1_9PRE5 = register("gold_block_b1_9pre5", method_9630(field_10205));
    public static final class_2356 DANDELION_C0_0_20A = register("dandelion_c0_0_20a", new class_2356(class_1294.field_5922, 0.35F, method_9630(field_10182)));
    public static final class_2248 POTTED_DANDELIONS_C0_0_20A = registerWithoutItem("potted_dandelion_c0_0_20a", createFlowerPotBlock(DANDELION_C0_0_20A));
    public static final class_2356 ROSE_C0_0_20A = register("rose_c0_0_20a", new class_2356(class_1294.field_5925, 5.0F, method_9630(field_10449)));
    public static final class_2248 POTTED_ROSE_C0_0_20A = registerWithoutItem("potted_rose_c0_0_20a", createFlowerPotBlock(ROSE_C0_0_20A));
    public static final class_2356 POPPY_1_7 = register("poppy_1_7", new class_2356(class_1294.field_5925, 5.0F, method_9630(field_10449)));
    public static final class_2248 POTTED_POPPY_1_7 = registerWithoutItem("potted_poppy_1_7", createFlowerPotBlock(POPPY_1_7));
    public static final class_2381 BROWN_MUSHROOM_C0_0_20A = register("brown_mushroom_c0_0_20a", new class_2381(method_9630(field_10251)), new class_1792.class_1793().method_19265(FoodList.BROWN_MUSHROOM_C0_0_20A_SETTINGS));
    public static final class_2248 POTTED_BROWN_MUSHROOM_C0_0_20A = registerWithoutItem("potted_brown_mushroom_c0_0_20a", createFlowerPotBlock(BROWN_MUSHROOM_C0_0_20A));
    public static final class_2381 RED_MUSHROOM_C0_0_20A = register("red_mushroom_c0_0_20a", new class_2381(method_9630(field_10559)), new class_1792.class_1793().method_19265(FoodList.RED_MUSHROOM_C0_0_20A_SETTINGS));
    public static final class_2248 POTTED_RED_MUSHROOM_C0_0_20A = registerWithoutItem("potted_red_mushroom_c0_0_20a", createFlowerPotBlock(RED_MUSHROOM_C0_0_20A));
    public static final class_2482 STONE_SLAB_C0_26ST = register("stone_slab_c0_26st", new class_2482(method_9630(field_10136)));
    public static final class_2248 IRON_BLOCK_C0_26ST = register("iron_block_c0_26st", method_9630(field_10085));
    public static final class_2248 IRON_BLOCK_A1_2_0 = register("iron_block_a1_2_0", method_9630(field_10085));
    public static final class_2248 IRON_BLOCK_B1_9PRE5 = register("iron_block_b1_9pre5", method_9630(field_10085));
    public static final class_2530 TNT_C0_26ST = register("tnt_c0_26st", new class_2530(method_9630(field_10375)));
    public static final class_2530 TNT_C0_28A = register("tnt_c0_28a", new class_2530(method_9630(field_10375)));
    public static final class_2248 MOSSY_COBBLESTONE_C0_26ST = register("mossy_cobblestone_c0_26st", method_9630(field_9989));
    public static final class_2248 MOSSY_COBBLESTONE_B1_8 = register("mossy_cobblestone_b1_8", method_9630(field_9989));
    public static final class_2248 BRICKS_C0_26ST = register("bricks_c0_26st", method_9630(field_10104));
    public static final class_2248 BRICKS_A1_0_11 = register("bricks_a1_0_11", method_9630(field_10104));
    public static final class_2248 BOOKSHELF_C0_26ST = register("bookshelf_c0_26st", method_9630(field_10504));
    public static final class_2248 BOOKSHELF_B1_9PRE5 = register("bookshelf_b1_9pre5", method_9630(field_10504));
    public static final class_2248 OBSIDIAN_C0_28A = register("obsidian_c0_28a", method_9630(field_10540));
    public static final class_2431 DIAMOND_ORE_IN20100128 = register("diamond_ore_in20100128", new class_2431(class_6019.method_35017(3, 7), method_9630(field_10442)));
    public static final class_2431 DIAMOND_ORE_1_14 = register("diamond_ore_1_14", new class_2431(class_6019.method_35017(3, 7), method_9630(field_10442)));
    public static final class_2248 DIAMOND_BLOCK_IN20100128 = register("diamond_block_in20100128", method_9630(field_10201));
    public static final class_2248 DIAMOND_BLOCK_A1_2_0 = register("diamond_block_a1_2_0", method_9630(field_10201));
    public static final class_2248 DIAMOND_BLOCK_B1_9PRE5 = register("diamond_block_b1_9pre5", method_9630(field_10201));
    public static final class_2248 CRAFTING_TABLE_IN20100131 = register("crafting_table_in20100131", method_9630(field_9980));
    public static final class_2248 CRAFTING_TABLE_1_14 = register("crafting_table_1_14", method_9630(field_9980));
    public static final class_2248 FURNACE_IN20100219 = register("furnace_in20100219", class_4970.class_2251.method_9637().method_31710(class_3620.field_16023).method_51368(class_2766.field_12653).method_29292().method_9632(3.5F));
    public static final class_2248 LIT_FURNACE_IN20100219 = register("lit_furnace_in20100219", class_4970.class_2251.method_9637().method_31710(class_3620.field_16023).method_51368(class_2766.field_12653).method_29292().method_9632(3.5F).method_9631((state) -> 13));
    public static final class_2248 FURNACE_B1_2  = register("furnace_b1_2", method_9630(FURNACE_IN20100219));
    public static final class_2248 LIT_FURNACE_B1_2 = register("lit_furnace_b1_2", method_9630(LIT_FURNACE_IN20100219));
    public static final class_2399 LADDER_INF20100607 = register("ladder_inf20100607", new class_2399(method_9630(field_9983)));
    public static final class_2399 LADDER_INF20100618 = register("ladder_inf20100618", new class_2399(method_9630(field_9983)));
    public static final class_2510 WOODEN_STAIRS_RD20090515 = register("wooden_stairs_rd20090515", new class_2510(WOODEN_PLANKS_RD20090515.method_9564(), method_9630(field_10563)));
    public static final class_2510 WOODEN_STAIRS_RD161348 = register("wooden_stairs_rd161348", new class_2510(WOODEN_PLANKS_RD161348.method_9564(), method_9630(field_10563)));
    public static final class_2510 WOODEN_STAIRS_C0_0_14A = register("wooden_stairs_c0_0_14a", new class_2510(WOODEN_PLANKS_C0_0_14A.method_9564(), method_9630(field_10563)));
    public static final class_2510 WOODEN_STAIRS_INF20100629 = register("wooden_stairs_inf20100629", new class_2510(WOODEN_PLANKS_C0_0_15A.method_9564(), method_9630(field_10563)));
    public static final class_2510 WOODEN_STAIRS_B1_9PRE5 = register("wooden_stairs_b1_9pre5", new class_2510(WOODEN_PLANKS_B1_9PRE5.method_9564(), method_9630(field_10563)));
    public static final class_2510 COBBLESTONE_STAIRS_RD20090515 = register("cobblestone_stairs_rd20090515", new class_2510(COBBLESTONE_RD20090515.method_9564(), method_9630(field_10596)));
    public static final class_2510 COBBLESTONE_STAIRS_C0_0_14A = register("cobblestone_stairs_c0_0_14a", new class_2510(COBBLESTONE_C_0_0_14A.method_9564(), method_9630(field_10596)));
    public static final class_2510 COBBLESTONE_STAIRS_B1_7 = register("cobblestone_stairs_b1_7", new class_2510(COBBLESTONE_B1_7.method_9564(), method_9630(field_10596)));
    public static class_2960 SIGN_INF20100607_TEXTURE = Blocktopia.id("entity/signs/wooden_c0_0_15a");
    public static final class_2527 TORCH_IN20100124_2 = registerWithoutItem("torch_in20100124_2", new class_2527(class_2398.field_11240, class_4970.class_2251.method_9637().method_9634().method_9618().method_9631((state) -> 14).method_9626(class_2498.field_11547).method_50012(class_3619.field_15971)));
    public static final class_2555 WALL_TORCH_IN20100124_2 = registerWithoutItem("wall_torch_in20100124_2", new class_2555(class_2398.field_11240, class_4970.class_2251.method_9637().method_9634().method_9618().method_9631((state) -> 14).method_9626(class_2498.field_11547).method_50012(class_3619.field_15971)));
    public static final BlocktopiaSignBlock SIGN_INF20100607 = registerWithoutItem("sign_inf20100607", new BlocktopiaSignBlock(SIGN_INF20100607_TEXTURE, class_4970.class_2251.method_9637().method_31710(class_3620.field_15996).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013()));
    public static final BlocktopiaWallSignBlock WALL_SIGN_INF20100607 = registerWithoutItem("wall_sign_inf20100607", new BlocktopiaWallSignBlock(SIGN_INF20100607_TEXTURE, class_4970.class_2251.method_9637().method_31710(class_3620.field_15996).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013()));
    public static final class_2323 WOODEN_DOOR_INF20100607 = register("wooden_door_inf20100607", new class_2323(BlockSetTypeList.WOODEN_C0_0_15A, method_9630(field_10149)));
    public static final class_2449 REDSTONE_ORE_A1_0_1 = register("redstone_ore_a1_0_1", new class_2449(method_9630(field_10080)));
    public static final class_2449 REDSTONE_ORE_1_14 = register("redstone_ore_1_14", new class_2449(method_9630(field_10080)));
    public static final class_2459 REDSTONE_TORCH_A1_0_1 = registerWithoutItem("redstone_torch_a1_0_1", new class_2459(method_9630(field_10523)));
    public static final class_2458 REDSTONE_WALL_TORCH_A1_0_1 = registerWithoutItem("redstone_wall_torch_a1_0_1", new class_2458(method_9630(field_10301)));
    public static final class_2488 SNOW_A1_0_4 = register("snow_a1_0_4", new class_2488(method_9630(field_10477)));
    public static final class_2248 ICE_A1_0_4 = register("ice_a1_0_4", method_9630(field_10295));
    public static final class_2248 SNOW_BLOCK_A1_0_5 = register("snow_block_a1_0_5", method_9630(field_10491));
    public static final class_2248 CLAY_BLOCK_A1_0_11 = register("clay_block_a1_0_11", method_9630(field_10460));
    public static final class_2354 WOODEN_FENCE_RD20090515 = register("wooden_fence_rd20090515", new class_2354(class_4970.class_2251.method_9637().method_51369().method_51368(class_2766.field_12651).method_9632(2.0F).method_9626(class_2498.field_11547).method_50013()));
    public static final class_2354 WOODEN_FENCE_RD161348 = register("wooden_fence_rd161348", new class_2354(class_4970.class_2251.method_9637().method_51369().method_51368(class_2766.field_12651).method_9632(2.0F).method_9626(class_2498.field_11547).method_50013()));
    public static final class_2354 WOODEN_FENCE_C0_0_14A = register("wooden_fence_c0_0_14a", new class_2354(class_4970.class_2251.method_9637().method_51369().method_51368(class_2766.field_12651).method_9632(2.0F).method_9626(class_2498.field_11547).method_50013()));
    public static final class_2354 WOODEN_FENCE_A1_0_17 = register("wooden_fence_a1_0_17", new class_2354(class_4970.class_2251.method_9637().method_51369().method_51368(class_2766.field_12651).method_9632(2.0F).method_9626(class_2498.field_11547).method_50013()));
    public static final class_2354 WOODEN_FENCE_B1_9PRE5 = register("wooden_fence_b1_9pre5", new class_2354(class_4970.class_2251.method_9637().method_51369().method_51368(class_2766.field_12651).method_9632(2.0F).method_9626(class_2498.field_11547).method_50013()));
    public static final class_2248 NETHERRACK_A1_2_0 = register("netherrack_a1_2_0", method_9630(field_10515));
    public static final class_2248 NETHERRACK_B1_9PRE5 = register("netherrack_b1_9pre5", method_9630(field_10515));
    public static final class_2492 SOUL_SAND_A1_2_0 = register("soul_sand_a1_2_0", new class_2492(method_9630(field_10114)));
    public static final class_2248 GLOWSTONE_A1_2_0 = register("glowstone_a1_2_0", method_9630(field_10171));
    public static final class_2248 GLOWSTONE_B1_9PRE5 = register("glowstone_b1_9pre5", method_9630(field_10171));
    public static final class_2276 CARVED_PUMPKIN_A1_2_0 = register("carved_pumpkin_a1_2_0", new class_2276(method_9630(field_10147)));
    public static final class_2276 JACK_O_LANTERN_A1_2_0 = register("jack_o_lantern_a1_2_0", new class_2276(method_9630(field_10009)));

    /*
    //1.0 Beta 10
    public static final Block LIGHT_GRAY_WOOL_B1_2 = register("light_gray_wool_b1_2", copy(WHITE_WOOL));
    public static final Block GRAY_WOOL_B1_2 = register("gray_wool_b1_2", copy(GRAY_WOOL));
    public static final Block BLACK_WOOL_B1_2 = register("black_wool_b1_2", copy(BLACK_WOOL));
    public static final Block BROWN_WOOL_B1_2 = register("brown_wool_b1_2", copy(BROWN_WOOL));
    public static final Block RED_WOOL_B1_2 = register("red_wool_b1_2", copy(RED_WOOL));
    public static final Block ORANGE_WOOL_B1_2 = register("orange_wool_b1_2", copy(ORANGE_WOOL));
    public static final Block YELLOW_WOOL_B1_2 = register("yellow_wool_b1_2", copy(YELLOW_WOOL));
    public static final Block LIME_WOOL_B1_2 = register("lime_wool_b1_2", copy(LIME_WOOL));
    public static final Block GREEN_WOOL_B1_2 = register("green_wool_b1_2", copy(GREEN_WOOL));
    public static final Block CYAN_WOOL_B1_2 = register("cyan_wool_b1_2", copy(CYAN_WOOL));
    public static final Block LIGHT_BLUE_WOOL_B1_2 = register("light_blue_wool_b1_2", copy(LIGHT_BLUE_WOOL));
    public static final Block BLUE_WOOL_B1_2 = register("blue_wool_b1_2", copy(BLUE_WOOL));
    public static final Block PURPLE_WOOL_B1_2 = register("purple_wool_b1_2", copy(PURPLE_WOOL));
    public static final Block MAGENTA_WOOL_B1_2 = register("magenta_wool_b1_2", copy(MAGENTA_WOOL));
    public static final Block PINK_WOOL_B1_2 = register("pink_wool_b1_2", copy(PINK_WOOL));
    public static final Block LIGHT_GRAY_WOOL_1_2_4 = register("light_gray_wool_1_2_4", copy(WHITE_WOOL));
    public static final Block GRAY_WOOL_1_2_4 = register("gray_wool_1_2_4", copy(GRAY_WOOL));
    public static final Block BLACK_WOOL_1_2_4 = register("black_wool_1_2_4", copy(BLACK_WOOL));
    public static final Block BROWN_WOOL_1_2_4 = register("brown_wool_1_2_4", copy(BROWN_WOOL));
    public static final Block RED_WOOL_1_2_4 = register("red_wool_1_2_4", copy(RED_WOOL));
    public static final Block ORANGE_WOOL_1_2_4 = register("orange_wool_1_2_4", copy(ORANGE_WOOL));
    public static final Block YELLOW_WOOL_1_2_4 = register("yellow_wool_1_2_4", copy(YELLOW_WOOL));
    public static final Block LIME_WOOL_1_2_4 = register("lime_wool_1_2_4", copy(LIME_WOOL));
    public static final Block GREEN_WOOL_1_2_4 = register("green_wool_1_2_4", copy(GREEN_WOOL));
    public static final Block CYAN_WOOL_1_2_4 = register("cyan_wool_1_2_4", copy(CYAN_WOOL));
    public static final Block LIGHT_BLUE_WOOL_1_2_4 = register("light_blue_wool_1_2_4", copy(LIGHT_BLUE_WOOL));
    public static final Block BLUE_WOOL_1_2_4 = register("blue_wool_1_2_4", copy(BLUE_WOOL));
    public static final Block PURPLE_WOOL_1_2_4 = register("purple_wool_1_2_4", copy(PURPLE_WOOL));
    public static final Block MAGENTA_WOOL_1_2_4 = register("magenta_wool_1_2_4", copy(MAGENTA_WOOL));
    public static final Block PINK_WOOL_1_2_4 = register("pink_wool_1_2_4", copy(PINK_WOOL));
    public static final CakeBlock CAKE_B1_2 = register("cake_b1_2", new CakeBlock(copy(CAKE)));
    public static final ExperienceDroppingBlock LAPIS_ORE_B1_2 = register("lapis_ore_b1_2", new ExperienceDroppingBlock(UniformIntProvider.create(2, 5), copy(LAPIS_ORE)));
    public static final ExperienceDroppingBlock LAPIS_ORE_1_14 = register("lapis_ore_1_14", new ExperienceDroppingBlock(UniformIntProvider.create(2, 5), copy(LAPIS_ORE)));
    public static final Block LAPIS_BLOCK_B1_2 = register("lapis_block_b1_2", copy(LAPIS_BLOCK));
    public static final Block LAPIS_BLOCK_1_6 = register("lapis_block_1_6", copy(LAPIS_BLOCK));
    public static final NoteBlock NOTE_BLOCK_B1_2 = register("note_block_b1_2", new NoteBlock(copy(NOTE_BLOCK)));
    public static final Block SANDSTONE_B1_2 = register("sandstone_b1_2", copy(SANDSTONE));
    public static final Block SANDSTONE_1_2_4 = register("sandstone_1_2_4", copy(SANDSTONE));
    public static final Block BIRCH_LOG_B1_2 = register("brich_log_b1_2", createLogBlock(MapColor.PALE_YELLOW, MapColor.OFF_WHITE));
    public static final Block BIRCH_LOG_1_7 = register("birch_log_1_7", createLogBlock(MapColor.PALE_YELLOW, MapColor.OFF_WHITE));
    public static final LeavesBlock BIRCH_LEAVES_B1_2 = register("birch_leaves_b1_2", new LeavesBlock(copy(BIRCH_LEAVES)));
    public static final Block SPRUCE_LOG_B1_2 = register("spuce_log_b1_2", createLogBlock(MapColor.SPRUCE_BROWN, MapColor.BROWN));
    public static final Block SPRUCE_LOG_1_7 = register("spruce_log_1_7", createLogBlock(MapColor.SPRUCE_BROWN, MapColor.BROWN));
    public static final LeavesBlock SPRUCE_LEAVES_B1_2 = register("spruce_leaves_b1_2", new LeavesBlock(copy(SPRUCE_LEAVES)));
    public static final SlabBlock COBBLESTONE_SLAB_RD20090515 = register("cobblestone_slab_rd20090515", new SlabBlock(copy(COBBLESTONE_SLAB)));
    public static final SlabBlock COBBLESTONE_SLAB_B1_3 = register("cobblestone_slab_b1_3", new SlabBlock(copy(COBBLESTONE_SLAB)));
    public static final SlabBlock COBBLESTONE_SLAB_B1_7 = register("cobblestone_slab_b1_7", new SlabBlock(copy(COBBLESTONE_SLAB)));
    public static final SlabBlock WOODEN_SLAB_RD20090515 = register("wooden_slab_rd20090515", new SlabBlock(copy(PETRIFIED_OAK_SLAB)));
    public static final SlabBlock WOODEN_SLAB_RD161348 = register("wooden_slab_rd161348", new SlabBlock(copy(PETRIFIED_OAK_SLAB)));
    public static final SlabBlock WOODEN_SLAB_C0_0_14A = register("wooden_slab_c0_0_14a", new SlabBlock(copy(PETRIFIED_OAK_SLAB)));
    public static final SlabBlock WOODEN_SLAB_B1_3 = register("wooden_slab_b1_3", new SlabBlock(copy(PETRIFIED_OAK_SLAB)));
    public static final SlabBlock WOODEN_SLAB_B1_9PRE5 = register("wooden_slab_b1_9pre5", new SlabBlock(copy(PETRIFIED_OAK_SLAB)));
    public static final SlabBlock SANDSTONE_SLAB_B1_2 = register("sandstone_slab_b1_2", new SlabBlock(copy(SANDSTONE_SLAB)));
    public static final SlabBlock SANDSTONE_SLAB_1_2_4 = register("sandstone_slab_1_2_4", new SlabBlock(copy(SANDSTONE_SLAB)));
    public static final Block SMOOTH_STONE_B1_3 = register("smooth_stone_b1_3", copy(SMOOTH_STONE));
    public static final RepeaterBlock REPEATER_B1_3 = register("repeater_b1_3", new RepeaterBlock(copy(REPEATER))); //Locked from 1.4.2
    public static final RepeaterBlock REPEATER_1_4_2 = register("repeater_1_4_2", new RepeaterBlock(copy(REPEATER)));
    */


    public static <T extends class_2248> T registerWithoutItem(String name, T block) {
        return class_2378.method_10230(class_7923.field_41175, Blocktopia.id(name), block);
    }
    public static <T extends class_2248> T register(String name, T block, class_1792.class_1793 settings) {
        T registered = registerWithoutItem(name, block);
        ItemInit.register(name, new class_1747(registered, settings));
        return registered;
    }
    public static <T extends class_2248> T register(String name, T block) {
        return register(name, block, new class_1792.class_1793());
    }
    public static <T extends class_2248> T register(String name, class_4970.class_2251 settings) {
        return (T) register(name, new class_2248(settings), new class_1792.class_1793());
    }
    public static class_2248 createLogBlock(class_3620 topMapColor, class_3620 sideMapColor) {
        return new class_2465(
                class_4970.class_2251.method_9637()
                        .method_51520(state -> state.method_11654(class_2465.field_11459) == class_2350.class_2351.field_11052 ? topMapColor : sideMapColor)
                        .method_51368(class_2766.field_12651)
                        .method_9632(2.0F)
                        .method_9626(class_2498.field_11547)
                        .method_50013()
        );
    }
    public static class_2248 createFlowerPotBlock(class_2248 flower) {
        return new class_2362(flower, class_4970.class_2251.method_9637().method_9618().method_22488().method_50012(class_3619.field_15971));
    }

    public static void load() {}
}
